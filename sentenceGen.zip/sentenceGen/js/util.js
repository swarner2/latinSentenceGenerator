//***************************************************************************
//***************GLOBAL VARIABLES*************************************
window.word = "word";
window.sentence = [];


//**************DOM NAVIGATION*****************************************

window.dom = {
	id :	function(id){
			return document.getElementById(id) || {};
	},
	cl : 	function(cl){
			return document.getElementsByClassName(cl) || {};
	}
};

//***************************************************************************
//**********UTILITY FUNCTIONS*******************************************
function initialize(){
	//-----------------
	//place any functions that need to be initialized here
	//-----------------

	//this needs to be initialized as it requires DOM Data
	initGrammar();
}

function checkConfig(obj){
	var map = [];
	
	for(var key in obj){
		if(obj[key].isOn){
			map.push(key);
		};
	};
	return map;
}
function random(obj){

	if( obj.constructor === Object){
		var map = [];
		var objectLength = function(obj){
			  var count = 0;
			  for(key in obj){count++; map.push(key)}
			  return count;
		};
		return map[Math.floor(Math.random() * objectLength(obj))];
	};		
	if( obj.constructor === Array){
		return obj[Math.floor(Math.random() * (obj.length) ) ];}
};
function checkWordType(word, type, action){
	if(word[type] != true){ action();}
};
function checkCaseUse(elementId){
	return dom.id(elementId).addEventListener("click", changeIsOn, false);
	function changeIsOn(){
		grammarList[elementId]['isOn'] = this.checked;
	}
	
}
function englishPluralNouns(word){
	var dontAddS = false;
	var exceptions={
		'boy': true, 
		'human': true,
		'walkway': true,
		'money': true,
		}
	if(!(word in exceptions)){
		if(word.match(/y$/)){ 
			word = word.replace(/y$/, 'ies')
			dontAddS = true;	
			}
		else if(word.match(/man$/)){ 
			word = word.replace(/man$/, 'men')
			dontAddS = true;
			}
	}
	if(!dontAddS){word = word + "s"}
	return word
};