
var initGrammar = function(){

	window.grammarList = {
		'1stF': {
			"nominative":{ sg: 'a', pl: 'ae'},
			"accusative":{ sg: 'am', pl: 'As'},
			"ablative":{ sg: 'A', pl: 'is'},
		},
		'2ndM': {
			"nominative":{ sg: 'us', pl: 'i'},
			"accusative":{ sg: 'um', pl: 'Os'},
			"ablative":{ sg: 'O', pl: 'is'},
		},
		'2ndN': {
			"nominative":{ sg: 'um', pl: 'a'},
			"accusative":{ sg: 'um', pl: 'a'},
			"ablative":{ sg: 'O', pl: 'is'},
		},
		'presentActive': {
			endings: {
				'1st': 		['o','as','at','amus','atis','ant'],
				'2nd' : 	['eo', 'es', 'et', 'emus', 'etis', 'ent'],
				'3rd' : 	['o', 'is', 'it', 'imus', 'itis', 'unt'],
				'3rd io':	['io', 'is', 'it', 'imus', 'itis', 'iunt'],
				'4th' : 	['io', 'is', 'it', 'imus', 'itis', 'iunt'],
			},
		},
		createWord : function(nounUse){
			var	use = grammarList[nounUse];
				//*************CLEAR OLD WORD*******************************
				delete use.word, use.decl, use.gender, use.number, use.ending, use.form, use.translation, use.meaning, use.types
				//************SET DEFAULT use**************************
				if(checkConfig(grammarList).join("").match(nounUse) == null){
	//				console.log('default ' + nounUse)
					use.gender = random(['M','F','N']);
					use.decl =  random(['1stF', '2ndN', '2ndM']);
						var decl = use.decl;
					use.number = random(['sg','pl']);
						var number = use.number;
					use.form = "____";
						var translation;
							if(number == 'sg'){translation = "the " + nounUse}
							if(number == 'pl'){translation = "the " + englishPluralNouns(nounUse)}
								else{translation = "the " + nounUse}	
					use.translation = translation;
					use.word = 'default ' + nounUse; 
					use.meaning = nounUse;
				}
				//************IF CHOSEN*****************************************
				if(checkConfig(grammarList).join("").match(nounUse)){
	//				console.log(nounUse + ' chosen')		
					use.word = dictionary["nouns"][random(dictionary["nouns"])];
						var word = use.word;
					use.decl =  word["decl"] + word["gen"];
						var decl = use.decl;
					use.gender = word["gen"]
					use.number = random(grammarList[decl][grammarList[nounUse]['nounCase']]);
						var number = use.number;
					use.ending = grammarList[decl][grammarList[nounUse]["nounCase"]][number];
						var ending = use.ending;
					if((number == 'sg') && (grammarList[nounUse]["nounCase"] == 'nominative')) {grammarList[nounUse].form = word["firstDict"] + " ";}
					else{grammarList[nounUse].form = word["stem"] + ending}
					var translation;
						if(number == 'sg'){translation = "the " + word["meaning"]}
						else{translation = "the " + englishPluralNouns(word["meaning"])};
					use.translation = translation;
					use.meaning= word["meaning"];
					use.types= word["types"];			
				}
				return word;		
		},
		'subject': {
			nounCase: "nominative",
			isOn: dom.id('subject').checked,
			check: checkCaseUse('subject'),
			create: function(){
				grammarList.createWord('subject')
				grammarList['verb'].number = grammarList['subject'].number
			},
		},
		'directObject': {
			nounCase: "accusative",
			isOn: dom.id('directObject').checked,
			check: checkCaseUse('directObject'),
			create: function(){grammarList.createWord('directObject')},
		},
		"prepositionAblative":{
			nounCase: "ablative",
			isOn: dom.id('prepositionAblative').checked,
			check: checkCaseUse('prepositionAblative'),
			create: function(){
				var prep = grammarList["prepositionAblative"];	
				delete prep.preposition, prep.form, prep.translation, prep.meaning, prep.word, prep.decl, prep.gender, prep.number, prep.ending, prep.types;
				if(checkConfig(grammarList).join("").match("prepositionAblative") == null){
					prep.translation = " ";
					prep.word = 'default ' + 'prepostionAblative'; 
					prep.meaning = " ";
					prep.form = " ";
				}
				if(checkConfig(grammarList).join("").match("prepositionAblative")){			
					prep.preposition = random(dictionary['prepositions']);
						while(!(dictionary['prepositions'][prep.preposition]['ablative'])){
							prep.preposition = random(dictionary['prepositions']);
							if('no ablative prep phrase'){console.log('beware of no ablative preps');}
						}
						//*************MAKE SURE THE NOUN IS THE RIGHT TYPE FOR THE PREP************
						var prepTypes = dictionary['prepositions'][prep.preposition]['types'];
						var isType = false;
						while(!(isType)){
							grammarList.createWord('prepositionAblative');
							var nounTypes = prep.word['types']
								if(nounTypes == undefined){prep.word.types = 'nothing'}
							for(var i = 0; i < prepTypes.length; i++){
								for(var j = 0; j < nounTypes.length; j++){
									if(prepTypes[i] == nounTypes[j]){isType = true;}
								}
							}				
						}
					prep.form = prep.preposition + " " + prep.form;
					prep.translation = dictionary['prepositions'][prep.preposition]['meaning']  + " " + prep.translation
				}
			},
			
		},
		"verb" : {
			isOn: dom.id('verb').checked,
			check: checkCaseUse('verb'),
	//		number: grammarList['subject']['number'],
			create: function(type, transitive){
			
				//*************MAIN SCOPE VARIABLES****************
				var verb = grammarList['verb'];
				var number = grammarList['subject']['number']
					if(!number) {console.log('oops no subject number for verb')}
				//***********RESET TO DEFAULT****************************************
				console.log('deleteing verb, ', verb)
				delete verb.word, verb.conj, verb.ending, verb.form, verb.meaning, verb.types, verb.translation;

				//*******************SET DEFAULT****************************************
				verb.meaning = "verb";
				if(checkConfig(grammarList).join("").match('verb') == null){
					verb.word = 'default';
						var word = verb.word
					verb.form = "____";
						var form = verb.form
					verb.translation = verb.meaning;
						if(number == 'sg'){verb.translation = verb.meaning + "s"}
						if(number == 'pl'){verb.translation = verb.meaning}
	//				console.log(verb.word + " verb created")
				}	
				if(checkConfig(grammarList).join("").match('verb')){
					verb.word = dictionary["verbs"][random(dictionary["verbs"])];
						var word = verb.word
						//Check for directObject
	/*				if(sentence.join("").match("directObject"))
						if (word['intransitive'] == true){
							return grammarList["verb"].create();
						}
	*/
					//Temp stop intransitives
					if (word['intransitive']){
							return grammarList["verb"].create();
						}
					verb.conj = word['conj']
						var conj =  verb.conj
					var ending;
						if(number == 'sg'){ending = grammarList['presentActive']['endings'][conj][2]};
						if(number == 'pl'){ending = grammarList['presentActive']['endings'][conj][5]};
						verb.ending = ending;
					verb.form = word['presStem'] + ending;
						var form = verb.form;
					var translation;
						if(number == 'sg'){translation = word['meaning'] + 's'};
						if(number == 'pl'){translation =  word['meaning']};
						verb.translation = translation;
					verb.meaning = word['meaning'];
				}
				return word;
			}
		},
	}
}